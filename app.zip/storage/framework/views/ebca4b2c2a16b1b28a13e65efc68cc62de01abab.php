

<?php $__env->startSection('content'); ?>
    <section id="features" class="grade">
        <div class="container">
            <div class="grade-text">
                <h1 class="text-center">Welcome</h1>
                <h2 class="text-center">Begin your journey to grade cards.</h2>


                <?php if(session()->has('message')): ?>
                    <p class="alert alert-success text-center"><?php echo e(session()->get('message')); ?></p>
                <?php endif; ?>


                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-6">
                        <form action="<?php echo e(route('grade-card.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputFullname1">Full Name</label>
                                <input type="text" name="name" class="form-control" id="exampleInputFullname1"
                                    placeholder="Full name">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" name="email" class="form-control" id="exampleInputEmail1"
                                    aria-describedby="emailHelp" placeholder="Enter email">
                                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone
                                    else.</small>
                            </div>

                            <div class="form-group">
                                <label for="exampleFormControlTextarea1">Comments (Optional)</label>
                                <textarea class="form-control" name="comment" id="exampleFormControlTextarea1" rows="3"></textarea>
                            </div>

                            <div class="form-group">
                                <label for="exampleFormControlFile1">Upload your picture</label>
                                <input type="file" name="image" class="form-control-file form-control"
                                    id="exampleFormControlFile1">
                            </div>
                            <button type="submit" class="btn btn-danger submit-btn-grade">Submit</button>
                        </form>
                    </div>

                    <div class="col-md-6 result-parent">
                        
                        <?php if(isset($data)): ?>
                        
                            <div class="alert alert-success result-alert" role="alert"><span class="text-danger"><?php echo e($data >= 5 ? ($data >= 8 ? "Outstanding" : "Well done !") : "Opps !"); ?></span> 
                                <br> <br> <h1><?php echo e($data >= 8 ? "Awesome you" : "You"); ?> have got <span class="text-danger"><?php echo e($data); ?></span> grade rating.</h1>
                                <br><img src="<?php echo e($data >= 5 ? asset('frontend/img/celebrate.png') : asset('frontend/img/opps.png')); ?>" alt="">
                            </div>
                        <?php else: ?>
                        <div class="image-poke"></div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\card-grader\resources\views/frontend/grade.blade.php ENDPATH**/ ?>